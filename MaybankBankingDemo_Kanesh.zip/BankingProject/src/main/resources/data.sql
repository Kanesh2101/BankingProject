
insert into customer values  (default,'test', 'test');


insert into account values  (default, 1, 'Savings', 20 , 1);
