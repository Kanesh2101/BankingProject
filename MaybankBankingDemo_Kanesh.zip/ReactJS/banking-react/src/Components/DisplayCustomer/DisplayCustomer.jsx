import React, { useEffect, useState } from "react";
import { Component } from "react";



  const DisplayCustomer = (props) => {
    
   return (
    
    <div className="App">

        <br></br>

           <table className="table " id='customers' style={{textAlign: 'center'}}>
                <thead>
                    <tr className='black-font-16-sans col-12'>
                        <th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Accounts</th>
                    </tr>
                </thead>
                <tbody>
                    <tr key={props.customer.id} >
                        <td scope="row">{props.customer.id}</td>
                        <td style={{letterSpacing : "1.5px"}}>{props.customer.name}</td>
                        <td >{props.customer.email}</td>
                    </tr> 
                </tbody>
            </table>
            <br></br>
    </div>
    )     
  

}

export default DisplayCustomer