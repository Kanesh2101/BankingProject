import { useState } from "react";

const Home = ()=>{
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [getResponse, setResponse] = useState("");


    const onNameChange = (event)=>{ 
        let searchFieldString = event.target.value.toLocaleLowerCase();
        setName(searchFieldString) ;
      }

      const onEmailChange = (event)=>{ 
        let searchFieldString = event.target.value.toLocaleLowerCase();
        setEmail(searchFieldString) ;
      }

      const onSubmitButton = (e) =>{
      
        e.preventDefault();
        let res = fetch("/addCustomers", {
        method: "POST",
        headers: {
            'Accept': 'application/json, text/plain',
            'Content-Type': 'application/json;charset=UTF-8'
        },
        body: JSON.stringify({
            name: name,
            email: email,
            }),
        }).then((response)=>{
            setResponse(response.status);
        });
      
      }
    return(
       
        <div className="App-left" style={{marginTop:"-90px"}}>
    <h3 style={{ marginRight: '35px' }}>Create Customer</h3>

            <form onSubmit={onSubmitButton}>
                <span>Customer Name: </span>
                <input type="text" required onChange={onNameChange}></input>
                <br></br>
                <span>Customer Email: </span>
                <input type="email" required onChange={onEmailChange}></input>
                <br></br>
                <button>Submit</button>
            </form>
            <br>
            </br><br></br>
            {getResponse =="200" ? <span>Successfully Created</span>:<span>Create Unsuccesfull</span> }
        </div>

        

    )

}

export default Home;