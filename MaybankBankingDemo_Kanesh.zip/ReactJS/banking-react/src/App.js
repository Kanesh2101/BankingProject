import './App.css';
import DisplayCustomer from './Components/DisplayCustomer/DisplayCustomer.jsx';
import Create from './Components/DisplayCustomer/CreateCustomer';


import { Component } from 'react';

class App extends Component{
  constructor(){
    super();
    this.state = {
      customer:[],     
      searchField:"",
      buttonClicked: false
    }  
    this.inputString= "";

  }

   onSearchChange = (event)=>{ 
    let searchFieldString = event.target.value.toLocaleLowerCase();
    this.setState({searchField : searchFieldString}) ;
  }

  
  onSubmit = () => {
  fetch(
    "/getCustomers/"+ this.state.searchField)
      .then((res) => res.json())
      .then((json) => {
          this.setState({
              customer: json,
              buttonClicked: true
          });
    })
  };

  render(){
    let {customer} = this.state.customer;
    console.log("test", this.state);
    let {onSearchChange} = this;
    let {onSubmit} = this;
   
    return (
      
      <div className="App">
      <h1 className='app-title'>Customer Details</h1>
      <div className="App-right">
      <h3 style={{ marginRight: '35px' }}>Inquire Customer</h3>
      <input
            type='search' placeholder="Enter Customer Name"
            onChange={onSearchChange} 
        />
     
        <button onClick={onSubmit} >Search</button>
        </div>
        <br></br>
        <Create/>
        {this.state.buttonClicked ? <DisplayCustomer  customer={this.state.customer}/>:<span></span> }
        {/* <DisplayCustomer  customer={this.state.customer}/> */}
        {/* <CardList monsters={filterd}/> */}
      </div>
    );
  }
 
}

export default App;
